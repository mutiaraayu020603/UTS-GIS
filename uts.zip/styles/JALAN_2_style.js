var size = 0;
var placement = 'point';
function categories_JALAN_2(feature, value, size, resolution, labelText,
                       labelFont, labelFill, bufferColor, bufferWidth,
                       placement) {
                switch(value.toString()) {case 'AIRLANGGA - GUBENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(53,213,42,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'AIRLANGGA - KERTAJAYA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,100,134,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'AIRLANGGA - MOJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(57,234,78,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'AMPEL - SIDOTOPO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(33,239,136,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(194,211,83,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - GENTING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,90,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - KREMBANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,32,173,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - SAWAHAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,224,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - SUKOMANUNGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(51,121,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ASEMROWO - TANDES':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(105,143,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BABATAN - BALASKLUMPRIK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,130,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BABATAN - WIYUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(223,218,76,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BABATJERAWAT - SEMEMI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(115,218,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BABATJERAWAT - TAMBAKOSOWILANGON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(106,231,185,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BALONGSARI - GADEL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,193,111,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BALONGSARI - KARANGPOH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(87,218,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BANGKINGAN - SUMURWELUT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(207,188,95,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BANJARSUGIHAN - MANUKAN KULON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(65,218,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BANJARSUGIHAN - MANUKAN WETAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,188,114,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BANYUURIP - PUTATJAYA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(51,149,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BARATAJAYA - PUCANGSEWU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(185,230,103,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BEBEKAN - SEPANJANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(20,81,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BENDULMERISI - MARGOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(129,220,39,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BENDULMERISI - SIDOSERMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(129,84,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BENOWO - ASEMROWO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,59,32,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BENOWO - LAKARSANTRI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,222,52,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BENOWO - PAKAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(31,73,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BERBEK - WADUNGASRI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(14,194,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BIBIS - BALONGSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(83,183,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BIBIS - GADEL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,44,92,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BRINGIN - MADE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(63,161,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BRINGIN - SAMBIKEREP':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,94,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUBUTAN - ALUN-ALUNCONTONG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(48,54,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUBUTAN - GENTENGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,119,106,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUBUTAN - SAWAHAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,218,136,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BULAK - KENJERAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,141,60,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BULAKBANTENG - SIDOTOPO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,209,86,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BULAKBANTENG - TAMBAKWEDI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,210,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BULAKBANTENG - TANAHKALIKEDINDING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,219,107,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNATARAN - MANUKAN KULON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(84,206,23,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNGURASIH - KEDUNGREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(47,75,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNTARAN - BALONGSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(90,167,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNTARAN - BANJARSUGIHAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,160,98,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNTARAN - BIBIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,91,66,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'BUNTARAN - MANUKAN WETAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(135,233,43,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DARMO - JAGIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(169,43,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DARMO - NGAGEL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(34,80,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DR.SUTOMO - KEPUTRAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,76,88,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHKUPANG - DUKUHPAKIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(110,220,216,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHPAKIS - GUNUNGSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(114,18,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHPAKIS - JAMBANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,66,130,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHPAKIS - WIYUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,70,70,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHPAKIS - WONOKROMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,124,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'DUKUHSUTOREJO - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(203,236,82,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GADEL - TANDES KIDUL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,188,55,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GADEL - TUBANAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(142,98,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GADING - KENJERAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,182,138,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GADING - PLOSO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(190,32,229,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GADUNG - MULUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,68,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GAYUNGAN - DUKUHMENANGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(231,32,155,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GAYUNGAN - MENANGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(153,219,21,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GAYUNGAN - WONOCOLO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(53,81,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GEBANGPUTIH - KEPUTIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(44,130,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GEDANGASIN - TANDES KIDUL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(33,235,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GEDANGASIN - TANDES LOR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(92,208,90,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GENTENG - EMBONGKALIASIN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,110,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GENTENG - GUBENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(76,235,161,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GENTENG - KETABANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(204,28,198,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GENTENG - TAMBAKSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(188,231,129,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GENTENG - TEGALSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(102,222,50,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GREGES - ASEMROWO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(42,45,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GREGES - KALIANAK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(220,177,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GRESIK - KOTA SURABAYA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,101,126,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - KERTAJAYA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,101,29,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,14,131,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - SUKOLILO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(141,39,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - TENGGILISMEJOYO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,223,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - WONOCOLO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(117,215,153,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUBENG - WONOKROMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,123,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUNDIH - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(189,74,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUNDIH - TEMBOKDUKUH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(140,110,221,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'GUNUNGANYAR - GUNUNGANYAR TAMBAK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(183,22,219,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JAMBANGAN - GAYUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(238,97,170,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JAMBANGAN - KEBONSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(169,42,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JANTI - WEDORO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(197,109,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JEMURWONOSARI - SIDOSERMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(135,119,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JEMURWONOSARI - SIWALANKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,208,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JEPARA - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(120,62,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JEPARA - GUNDIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(32,213,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'JERUK - LIDAHKULON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,110,18,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIANAK - ASEMROWO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(163,102,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIANAK - GENTING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(228,134,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIJUDAN - DUKUHSUTOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(137,215,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIJUDAN - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,232,20,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIRUNGKUT - KEDUNGBARUK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,168,79,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIRUNGKUT - PENJARINGANSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(33,239,174,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALIRUNGKUT - RUNGKUT KIDUL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,61,13,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALISARI - DUKUHSUTOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,52,159,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KALISARI - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(96,209,194,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KANDANGAN - KLAKAHREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(181,52,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KAPASAN - TAMBAKREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(221,195,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KAPASARI - KETABANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(36,235,149,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARAH - JAMBANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(88,223,35,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARANGPILANG - JAMBANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(233,192,69,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARANGPILANG - KEBRAON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,27,139,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARANGPOH - GADEL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,159,128,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARANGPOH - GEDANGASIN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,80,217,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KARANGPOH - TANDES KIDUL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(107,161,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEBONSARI - PAGESANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,158,125,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDUNGBARUK - PENJARINGANSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,126,149,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDUNGCOWEK - KENJERAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(133,116,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDUNGCOWEK - TANAHKALIKEDINDING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(143,109,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDUNGDORO - TEGALSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,66,120,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDUNGDORO - WONOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(70,67,207,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEDURUS - KEBRAON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,116,162,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEJAWANPUTIHTAMBAK - KALISARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,57,13,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KEMAYORAN - KREMBANGAN SELATAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(240,118,62,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENDANGSARI - KUTISARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,162,121,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENJERAN - KOMPLEKKENJERAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(51,217,59,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENJERAN - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(70,219,132,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENJERAN - SIMOKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(82,204,106,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENJERAN - SUKOLILO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,41,38,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KENJERAN - TAMBAKSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,120,133,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KERTAJAYA - BARATAJAYA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(239,123,152,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KERTAJAYA - PUCANGSEWU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,132,163,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KETABAN - EMBONGKALIASIN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(86,122,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KETINTANG - GAYUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(188,207,111,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KLAMPISNGASEM - GEBANGPUTIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,72,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KLAMPISNGASEM - KEPUTIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(48,155,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KLAMPISNGASEM - SEMOLOWARU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(121,225,105,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KOMPLEKKENJERAN - SUKOLILO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,51,188,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KOTA SURABAYA - SIDOARJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,215,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KREMBANGAN - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(72,126,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KREMBANGAN - PABEANCANTIKAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(142,98,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KREMBANGAN - TAWANGSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(33,231,152,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KREMBANGAN UTARA - NYAMPLUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,92,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'KUPANGKRAJAN - BANYUURIP':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(213,123,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LAKARSANTRI - JERUK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(97,97,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LAKARSANTRI - KARANGPILANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,82,107,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LAKARSANTRI - SUKOMANUNGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(114,206,145,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LAKARSANTRI - WIYUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,69,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LIDAH KULON - BANGKINGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,143,41,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LIDAH KULON - LIDAH WETAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(67,171,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LIDAHWETAN - BANGKINGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,98,169,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LIDAHWETAN - SUMURWELUT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(81,102,224,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LONTAR - LIDAH KULON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(118,205,51,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'LONTAR - LIDAH WETAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(14,153,240,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MADE - JERUK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(53,221,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MADE - LAKARSANTRI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(89,209,56,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MADE - SAMBIKEREP':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(149,238,127,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MANUKAN KULON - MANUKAN WETAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(33,56,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MANUKAN WETAN - BIBIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,15,142,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MARGOREJO - JEMURWONOSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,59,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MARGOREJO - SIDOSERMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(202,94,154,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MEDOKAN SEMAMPIR - KEPUTIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,73,227,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MENANGGAL - DUKUHMENANGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(23,201,73,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MENURPUMPUNGAN - KLAMPISNGASEM':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,36,29,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MENURPUMPUNGAN - NYINDENJANGKUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,117,106,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MENURPUMPUNGAN - SEMOLOWARU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(215,94,137,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MOROKREMBANGAN - DUPAK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(83,211,58,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MOROKREMBANGAN - KEMAYORAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(236,170,104,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MOROKREMBANGAN - PERAK BARAT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(234,64,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MULYOREJO - MAYARSABRANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(65,208,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'MULYOREJO - SUKOLILO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(176,233,32,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NGAGEL - JAGIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(118,225,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NGAGEL - NGAGELREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(82,237,162,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NGAGELREJO - JAGIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(165,233,120,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NGELOM - WONOCOLO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(189,202,90,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NYAMPLUNGAN - BONGKARAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,231,78,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'NYINDENJANGKUNGAN - MEDOKAN SEMAMPIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(210,150,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PABEANCANTIKAN - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,202,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PABEANCANTIKAN - GENTENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(54,225,24,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PABEANCANTIKAN - SEMAMPIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(193,112,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PABEANCANTIKAN - SIMOKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,152,41,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PACARKELING - PACARKEMBANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(118,31,212,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PAKAL - BABAT JERAWAT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(67,207,172,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PAKAL - ROMOKALISARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(102,205,148,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PANJANGJIWO - PRAPEN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,78,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PANJANGJIWO - TENGGILISMEJOYO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(226,137,231,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PEGIRIAN - SIDOTOPO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,210,91,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PENELEH - KAPASARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(166,24,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PENELEH - KETABANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,227,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PENGALANGAN - SETRO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,210,29,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PENJARINGANSARI - MEDOKANAYU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(117,106,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PENJARINGANSARI - RUNGKUTKIDUL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(239,193,102,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PERAK - KEMAYORAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,135,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PERAK UTARA - PERAK TIMUR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(163,81,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PERAKTIMUR - KREMBANGAN UTARA':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(169,238,78,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PETEMON - KUPANGKRAJAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(154,117,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PETEMON - SAWAHAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,116,73,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PLOSO - PACARKEMBANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(35,234,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PRADAHKALIKENDAL - DUKUHPAKIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,239,157,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'PUTATJAYA - PAKIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(68,84,221,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RANDEGANSARI - GADUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,138,117,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RANGKAH - GADING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(186,201,113,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RANGKAH - PLOSO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(52,228,122,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ROMOKALISARI - BABATJERAWAT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(21,230,118,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'ROMOKALISARI - TAMBAKOSOWILANGON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(125,232,200,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RUNGKUT - GUNUNGANYAR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(41,200,20,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RUNGKUT TENGAH - GUNUNGANYAR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(63,228,192,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RUNGKUT TENGAH - RUNGKUTMENANGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(157,65,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'RUNGKUTMENANGGAL - GUNUNGANYAR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(174,214,81,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAMBIKEREP - JERUK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(109,213,201,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAMBIKEREP - LIDAH KULON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(228,110,187,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAMBIKEREP - LONTAR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(218,47,133,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWAHAN - DUKUHPAKIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(155,225,133,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWAHAN - GENTENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(26,219,184,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWAHAN - KUPANGKRAJAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(21,37,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWAHAN - TEGALSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(217,227,34,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWAHAN - WONOKROMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(83,64,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWUNGGALING - DARMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(200,210,55,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SAWUNGGALING - WONOKROMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,155,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMAMPIR - KENJERAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(72,212,133,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMAMPIR - SIMOKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(206,41,203,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMEMI - KANDANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(129,233,80,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMEMI - KLAKAHREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(62,181,202,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMEMI - TAMBAKOSOWILANGON':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,15,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMOLOWARU - KEPUTIH':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(113,204,108,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMOLOWARU - MEDOKAN SEMAMPIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(21,136,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SEMOLOWARU - NYINDENJANGKUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(19,170,208,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIDODADI - KAPASAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(176,86,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIDODADI - SIMOKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(227,210,24,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIDOTOPO WETAN - TANAHKALIKEDINDING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,90,191,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOKERTO - GENTENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(88,157,236,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOKERTO - KAPASAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(89,209,75,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOKERTO - TAMBAKREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(25,194,213,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOKERTO - TAMBAKSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(239,21,119,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOLAWANG - SIDODADI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(191,109,238,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOLAWANG - SIMOKERTO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(37,31,215,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SIMOMULYO - SONOKWIJENAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(173,208,58,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SONOKWIJENAN - PUTATGEDE':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(192,101,228,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOLILO - RUNGKUT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,181,141,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOLILO - TENGGILISMEJOYO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(38,231,80,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOMANUNGGAL - DUKUHPAKIS':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(233,216,85,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOMANUNGGAL - SAWAHAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(48,233,112,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOMANUNGGAL - SIMOMULYO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(168,115,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOMANUNGGAL - SONOKWIJENAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(230,223,120,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOMANUNGGAL - WIYUNG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(134,201,87,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUKOREJO - SEGOROMADU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(143,44,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUMBEREJO - BENOWO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(39,226,86,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUMBEREJO - PAKAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(87,176,214,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'SUMBEREJO - ROMOKALISARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(216,57,67,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKBERAS - JONO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,34,138,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKDONO - SUMBEREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,54,75,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKLANGON - GREGES':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(126,225,232,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKOSOWILANGON - KANDANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(54,225,94,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKREJO - TAMBAKOSO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(21,228,194,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKSARI - GENTENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(23,220,181,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKSARI - GUBENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(95,220,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKSARI - MULYOREJO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(209,70,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKSARI - PACARKELING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(69,111,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKSARI - PLOSO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(180,206,124,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKWEDI - KEDUNGCOWEK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,205,22,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAMBAKWEDI - TANAHKALIKEDINDING':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(73,140,222,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANAHKALIKEDINDING - BULAK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(225,149,131,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANDES - LAKARSANTRI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(61,48,233,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANDES - SUKOMANUNGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(201,95,98,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANDES KIDUL - TANDES LOR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(212,116,223,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANDES LOR - TUBANAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(172,221,26,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANDESKIDUL - TUBANAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(104,222,100,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANJUNGSARI - SONOKWIJENAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(130,121,229,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TANJUNGSARI - SUKOMANUNGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(85,227,130,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TAWANGSARI - NGELOM':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,134,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TEGALSARI - DR.SUTOMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(208,43,73,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TEGALSARI - GUBENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,63,123,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TEGALSARI - KEPUTRAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(91,143,211,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TEGALSARI - WONOKROMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(59,231,185,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TEMBOKDUKUH - BUBUTAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,159,85,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TENGGILISMEJOYO - GUNUNGANYAR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(143,116,225,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TENGGILISMEJOYO - KENDANGSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(142,218,19,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TENGGILISMEJOYO - PRAPEN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(214,97,204,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'TENGGILISMEJOYO - RUNGKUT':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(53,110,210,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'UJUNG - AMPEL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(151,116,234,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'UJUNG - PEGIRIAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(47,223,173,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'UJUNG - WONOKUSUMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(82,227,104,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WADUNGASRI - TAMBAKSUMUR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(67,239,179,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WARUNGGUNUNG - KARANGPILANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(211,152,89,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WIYUNG - BALASKLUMPRIK':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(77,185,209,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WIYUNG - JAJARTUNGGAL':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(161,18,205,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WIYUNG - JAMBANGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(207,37,237,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WIYUNG - KARANGPILANG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(52,189,239,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONKROMO - GAYUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(37,158,206,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOCOLO - BEBEKAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(94,60,220,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOCOLO - TENGGILISMEJOYO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(232,91,218,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOKROMO - GAYUNGAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(224,92,184,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOKROMO - GUBENG':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(72,204,230,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOKROMO - JAGIR':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(205,47,63,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOKROMO - WONOCOLO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(237,18,226,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOKUSUMO - PEGIRIAN':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(229,219,24,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOREJO - DR.SUTOMO':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(66,227,77,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOREJO - MEDOKANAYU':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(132,207,51,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOREJO - PENJARINGANSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(235,193,79,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
case 'WONOREJO - TEGALSARI':
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(222,59,179,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;
default:
                    return [ new ol.style.Style({
        stroke: new ol.style.Stroke({color: 'rgba(51,204,72,1.0)', lineDash: null, lineCap: 'square', lineJoin: 'bevel', width: 0.988}),
        text: createTextStyle(feature, resolution, labelText, labelFont,
                              labelFill, placement, bufferColor,
                              bufferWidth)
    })];
                    break;}};

var style_JALAN_2 = function(feature, resolution){
    var context = {
        feature: feature,
        variables: {}
    };
    var value = feature.get("JALAN");
    var labelText = "";
    size = 0;
    var labelFont = "13.0px \'Open Sans\', sans-serif";
    var labelFill = "#323232";
    var bufferColor = "";
    var bufferWidth = 0;
    var textAlign = "left";
    var offsetX = 8;
    var offsetY = 3;
    var placement = 'line';
    if (feature.get("JALAN") !== null) {
        labelText = String(feature.get("JALAN"));
    }
    
var style = categories_JALAN_2(feature, value, size, resolution, labelText,
                          labelFont, labelFill, bufferColor,
                          bufferWidth, placement);

    return style;
};
